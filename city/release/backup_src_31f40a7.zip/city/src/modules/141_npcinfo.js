  // src/npcinfo.js — NPCを選ぶと「いま何をしていて、どこへ向かうか」が分かる
  function npcStatus(id) {
    const w = G3.world, p = w.pop;
    const age = G3.ageOf(id);
    const d = G3.date();
    const a = personActivity(w, id, G3.S.min, d.dow);
    const dp = dayPlan(w, id, d.dow);
    const bn = (bi) => bi != null && bi >= 0 && G3.world.map.buildings[bi] ? G3.world.map.buildings[bi].name : "";
    const isHome = (bi) => bi === p.home[id];
    let who = "";
    try {
      who = p.flags[id] & F_STUDENT ? `${bn(p.school[id]) || "学校"}の生徒` : jobName(p, id) || "";
    } catch (_) {
    }
    let now = "", goal = "";
    if (a.s === 1) {
      now = isHome(a.to) ? "帰宅中" : dp && dp.kind === "school" ? "登校中" : "通勤中";
      if (a.bus) now += a.seg && a.seg.k === "walk" ? "(バス停との間を歩いています)" : "(バス)";
      else if (a.train) now += "(電車)";
      goal = isHome(a.to) ? "自宅" : bn(a.to);
    } else if (a.s === 2) {
      now = dp && dp.kind === "school" ? `授業中(${bn(a.at)})` : `仕事中(${bn(a.at)})`;
      const end = dp ? dp.b : null;
      if (end != null) goal = `${Math.floor(end)}:${String(Math.round(end % 1 * 60)).padStart(2, "0")}ごろ${dp.kind === "school" ? "下校" : "退勤"}して自宅へ`;
    } else if (a.s === 3) {
      now = "買い物・用事で外出中";
      goal = "用事が済んだら自宅へ";
    } else if (a.s === 4 || a.ride) {
      now = "電車で移動中";
      goal = bn(a.to) || "";
    } else {
      now = "自宅・近所で過ごしている";
      if (dp && G3.S.min / 60 < dp.a) goal = `${Math.floor(dp.a)}:${String(Math.round(dp.a % 1 * 60)).padStart(2, "0")}ごろ${dp.kind === "school" ? "登校" : "出勤"}(${bn(dp.dest)})`;
    }
    {
      const bs = (typeof busNpcStatus === "function" ? busNpcStatus(id) : null) || (typeof visitNpcStatus === "function" ? visitNpcStatus(id) : null) || (typeof campusNpcStatus === "function" ? campusNpcStatus(id) : null);
      if (bs) {
        now = bs;
        if (BUSSIM.drivers && BUSSIM.drivers.has(id)) who = "市営バスの運転士";
      }
    }
    return { who, age, now, goal };
  }
  function npcActivityHtml(id) {
    try {
      const s = npcStatus(id);
      return `<div class="tx small" style="background:#0d1a3399;border-radius:8px;padding:6px 8px;margin:4px 0">${s.age}歳${s.who ? "・" + esc4(s.who) : ""}<br>いま: ${esc4(s.now)}${s.goal ? `<br>このあと: ${esc4(s.goal)}` : ""}</div>`;
    } catch (e) {
      return "";
    }
  }
